<?php
namespace ModulesGarden\DomainsReseller\Registrar\IntelHoster\Calls;
use ModulesGarden\DomainsReseller\Registrar\IntelHoster\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class SaveEmailForwarding extends Call
{
    public $action = "domains/:domain/email";
    
    public $type = parent::TYPE_POST;
}