<?php
namespace ModulesGarden\DomainsReseller\Registrar\IntelHoster\Calls;
use ModulesGarden\DomainsReseller\Registrar\IntelHoster\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class ModifyNameServer extends Call
{
    public $action = "domains/:domain/nameservers/modify";
    
    public $type = parent::TYPE_POST;
}