<?php
namespace ModulesGarden\DomainsReseller\Registrar\IntelHoster\Calls;
use ModulesGarden\DomainsReseller\Registrar\IntelHoster\Core\Call;

/**
 * Description of RenewDomain
 *
 * @author inbs
 */
class RenewDomain extends Call
{
    public $action = "order/domains/renew";
    
    public $type = parent::TYPE_POST;
}